
import React from 'react';
import { Text, StyleSheet, View } from 'react-native'; 

const LessonComponent = () => {
    const nome = <Text>Samara</Text>

    return (
        <View>
            <Text style={styles.textStyle}>Iniciando React Native</Text>
            <Text>Meu nome é: {nome} </Text>
            
        </View>
    )
}
const styles = StyleSheet.create({
    textStyle: {
        fontSize: 45,
    },
    textDetalhe: {
        fontSize: 20,  
    }
})

export default LessonComponent