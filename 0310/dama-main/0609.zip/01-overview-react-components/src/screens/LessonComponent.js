import React from 'react'; 
import { Text, StyleSheet, View } from 'react-native';

const LessonComponent = () => {
    const nome = 'Laura'

    return (
        <View>
            <Text style={styles.textStyle}>Iniciando React Native</Text>
            <Text style={styles.pStyle}>Meu nome é {nome}</Text>
        </View>
    )
}

const styles = StyleSheet.create({  
    textStyle: {
        fontSize: 45,
        color: '#af7675',
        textAlign: 'center'
    },

    pStyle: {
        fontSize: 20,
        color: '#cb9897'
    }

    
})

export default LessonComponent
